CHANGELOG
=========

## Version 1.0.0
_2016-09-19_
- First stable version
